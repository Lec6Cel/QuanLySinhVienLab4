﻿
namespace QLSINHVIEN
{
    partial class frm_GiaoDien
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new System.Windows.Forms.Panel();
            bt_Thoat = new System.Windows.Forms.Button();
            pn_SV = new System.Windows.Forms.Panel();
            pn_TK = new System.Windows.Forms.Panel();
            pn_Lop = new System.Windows.Forms.Panel();
            pictureBox4 = new System.Windows.Forms.PictureBox();
            pictureBox3 = new System.Windows.Forms.PictureBox();
            pictureBox2 = new System.Windows.Forms.PictureBox();
            bt_TaiKhoan = new System.Windows.Forms.Button();
            bt_Lop = new System.Windows.Forms.Button();
            panel2 = new System.Windows.Forms.Panel();
            bt_DangXuat = new System.Windows.Forms.Button();
            lb_TenTK = new System.Windows.Forms.Label();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            bt_SinhVien = new System.Windows.Forms.Button();
            pictureBox6 = new System.Windows.Forms.PictureBox();
            panel3 = new System.Windows.Forms.Panel();
            label2 = new System.Windows.Forms.Label();
            panel_body = new System.Windows.Forms.Panel();
            pictureBox5 = new System.Windows.Forms.PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            panel3.SuspendLayout();
            panel_body.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            panel1.Controls.Add(bt_Thoat);
            panel1.Controls.Add(pn_SV);
            panel1.Controls.Add(pn_TK);
            panel1.Controls.Add(pn_Lop);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(bt_TaiKhoan);
            panel1.Controls.Add(bt_Lop);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(bt_SinhVien);
            panel1.Dock = System.Windows.Forms.DockStyle.Left;
            panel1.Location = new System.Drawing.Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(247, 573);
            panel1.TabIndex = 0;
            // 
            // bt_Thoat
            // 
            bt_Thoat.BackColor = System.Drawing.Color.LightSlateGray;
            bt_Thoat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            bt_Thoat.Dock = System.Windows.Forms.DockStyle.Bottom;
            bt_Thoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            bt_Thoat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            bt_Thoat.Image = Properties.Resources.icons8_power_64;
            bt_Thoat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            bt_Thoat.Location = new System.Drawing.Point(0, 509);
            bt_Thoat.Name = "bt_Thoat";
            bt_Thoat.Size = new System.Drawing.Size(247, 64);
            bt_Thoat.TabIndex = 12;
            bt_Thoat.Text = "Thoát";
            bt_Thoat.UseVisualStyleBackColor = false;
            bt_Thoat.Click += bt_Thoat_Click;
            // 
            // pn_SV
            // 
            pn_SV.BackColor = System.Drawing.Color.Blue;
            pn_SV.Location = new System.Drawing.Point(0, 199);
            pn_SV.Name = "pn_SV";
            pn_SV.Size = new System.Drawing.Size(15, 55);
            pn_SV.TabIndex = 2;
            pn_SV.Visible = false;
            // 
            // pn_TK
            // 
            pn_TK.BackColor = System.Drawing.Color.Blue;
            pn_TK.Location = new System.Drawing.Point(0, 314);
            pn_TK.Name = "pn_TK";
            pn_TK.Size = new System.Drawing.Size(15, 63);
            pn_TK.TabIndex = 3;
            pn_TK.Visible = false;
            // 
            // pn_Lop
            // 
            pn_Lop.BackColor = System.Drawing.Color.Blue;
            pn_Lop.Location = new System.Drawing.Point(0, 255);
            pn_Lop.Name = "pn_Lop";
            pn_Lop.Size = new System.Drawing.Size(15, 60);
            pn_Lop.TabIndex = 1;
            pn_Lop.Visible = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = System.Drawing.Color.FromArgb(192, 255, 255);
            pictureBox4.Image = Properties.Resources.Xem;
            pictureBox4.Location = new System.Drawing.Point(21, 324);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new System.Drawing.Size(48, 43);
            pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 11;
            pictureBox4.TabStop = false;
            pictureBox4.Visible = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = System.Drawing.Color.FromArgb(192, 255, 255);
            pictureBox3.Image = Properties.Resources.Lop;
            pictureBox3.Location = new System.Drawing.Point(21, 265);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new System.Drawing.Size(48, 43);
            pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 10;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = System.Drawing.Color.FromArgb(192, 255, 255);
            pictureBox2.Image = Properties.Resources.SinhVien;
            pictureBox2.Location = new System.Drawing.Point(21, 205);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new System.Drawing.Size(48, 43);
            pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 9;
            pictureBox2.TabStop = false;
            // 
            // bt_TaiKhoan
            // 
            bt_TaiKhoan.BackColor = System.Drawing.Color.LightSlateGray;
            bt_TaiKhoan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            bt_TaiKhoan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            bt_TaiKhoan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            bt_TaiKhoan.Location = new System.Drawing.Point(0, 314);
            bt_TaiKhoan.Name = "bt_TaiKhoan";
            bt_TaiKhoan.Size = new System.Drawing.Size(250, 64);
            bt_TaiKhoan.TabIndex = 8;
            bt_TaiKhoan.Text = "  Tài Khoản";
            bt_TaiKhoan.UseVisualStyleBackColor = false;
            bt_TaiKhoan.Visible = false;
            bt_TaiKhoan.Click += bt_TaiKhoan_Click;
            // 
            // bt_Lop
            // 
            bt_Lop.BackColor = System.Drawing.Color.LightSlateGray;
            bt_Lop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            bt_Lop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            bt_Lop.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            bt_Lop.Location = new System.Drawing.Point(0, 254);
            bt_Lop.Name = "bt_Lop";
            bt_Lop.Size = new System.Drawing.Size(250, 63);
            bt_Lop.TabIndex = 6;
            bt_Lop.Text = "Lớp";
            bt_Lop.UseVisualStyleBackColor = false;
            bt_Lop.Click += bt_Lop_Click;
            // 
            // panel2
            // 
            panel2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            panel2.Controls.Add(bt_DangXuat);
            panel2.Controls.Add(lb_TenTK);
            panel2.Controls.Add(pictureBox1);
            panel2.Dock = System.Windows.Forms.DockStyle.Top;
            panel2.Location = new System.Drawing.Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new System.Drawing.Size(247, 199);
            panel2.TabIndex = 3;
            // 
            // bt_DangXuat
            // 
            bt_DangXuat.BackColor = System.Drawing.Color.DarkSeaGreen;
            bt_DangXuat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            bt_DangXuat.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            bt_DangXuat.ForeColor = System.Drawing.Color.Ivory;
            bt_DangXuat.Location = new System.Drawing.Point(0, 0);
            bt_DangXuat.Name = "bt_DangXuat";
            bt_DangXuat.Size = new System.Drawing.Size(106, 40);
            bt_DangXuat.TabIndex = 0;
            bt_DangXuat.Text = "Đăng Xuất";
            bt_DangXuat.UseVisualStyleBackColor = false;
            bt_DangXuat.Click += bt_DangXuat_Click;
            // 
            // lb_TenTK
            // 
            lb_TenTK.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            lb_TenTK.AutoSize = true;
            lb_TenTK.BackColor = System.Drawing.Color.LightSlateGray;
            lb_TenTK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            lb_TenTK.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lb_TenTK.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            lb_TenTK.Location = new System.Drawing.Point(89, 161);
            lb_TenTK.Name = "lb_TenTK";
            lb_TenTK.Size = new System.Drawing.Size(138, 28);
            lb_TenTK.TabIndex = 1;
            lb_TenTK.Text = "Tên Tài Khoản";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = System.Drawing.Color.LightSlateGray;
            pictureBox1.Image = Properties.Resources.user;
            pictureBox1.Location = new System.Drawing.Point(0, 46);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(250, 110);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // bt_SinhVien
            // 
            bt_SinhVien.BackColor = System.Drawing.Color.LightSlateGray;
            bt_SinhVien.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            bt_SinhVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            bt_SinhVien.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            bt_SinhVien.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            bt_SinhVien.Location = new System.Drawing.Point(0, 193);
            bt_SinhVien.Name = "bt_SinhVien";
            bt_SinhVien.Size = new System.Drawing.Size(250, 63);
            bt_SinhVien.TabIndex = 4;
            bt_SinhVien.Text = "Sinh Viên";
            bt_SinhVien.UseVisualStyleBackColor = false;
            bt_SinhVien.Click += bt_SinhVien_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            pictureBox6.Image = Properties.Resources.icons8_menu_48;
            pictureBox6.Location = new System.Drawing.Point(0, 0);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new System.Drawing.Size(53, 40);
            pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 2;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // panel3
            // 
            panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            panel3.Controls.Add(pictureBox6);
            panel3.Controls.Add(label2);
            panel3.Dock = System.Windows.Forms.DockStyle.Top;
            panel3.Location = new System.Drawing.Point(247, 0);
            panel3.Name = "panel3";
            panel3.Size = new System.Drawing.Size(889, 199);
            panel3.TabIndex = 1;
            // 
            // label2
            // 
            label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Times New Roman", 34.2F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            label2.ForeColor = System.Drawing.Color.Cyan;
            label2.Location = new System.Drawing.Point(0, 64);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(172, 65);
            label2.TabIndex = 0;
            label2.Text = "Home";
            // 
            // panel_body
            // 
            panel_body.Controls.Add(pictureBox5);
            panel_body.Dock = System.Windows.Forms.DockStyle.Fill;
            panel_body.Location = new System.Drawing.Point(247, 199);
            panel_body.Name = "panel_body";
            panel_body.Size = new System.Drawing.Size(889, 374);
            panel_body.TabIndex = 2;
            // 
            // pictureBox5
            // 
            pictureBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            pictureBox5.Image = Properties.Resources._13;
            pictureBox5.Location = new System.Drawing.Point(0, 0);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new System.Drawing.Size(889, 374);
            pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 0;
            pictureBox5.TabStop = false;
            // 
            // frm_GiaoDien
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.FromArgb(128, 128, 255);
            ClientSize = new System.Drawing.Size(1136, 573);
            ControlBox = false;
            Controls.Add(panel_body);
            Controls.Add(panel3);
            Controls.Add(panel1);
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            Name = "frm_GiaoDien";
            WindowState = System.Windows.Forms.FormWindowState.Maximized;
            Load += frm_GiaoDien_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel_body.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button bt_DangXuat;
        private System.Windows.Forms.Label lb_TenTK;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button bt_TaiKhoan;
        private System.Windows.Forms.Button bt_Lop;
        private System.Windows.Forms.Button bt_SinhVien;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel_body;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel pn_Lop;
        private System.Windows.Forms.Panel pn_SV;
        private System.Windows.Forms.Panel pn_TK;
        private System.Windows.Forms.Button bt_Thoat;
        private System.Windows.Forms.PictureBox pictureBox6;
    }
}

